﻿Show me the data structures project
Problem 1: LRU Cache
I have used a doubly linked list along with a dictionary to achieve this task. The most operations here are get and set.
Initial operation is to 
Set operation: Here every time I come across a new node I am adding it to the front of the cache taking the cache capacity into consideration and also storing it as key values pairs in the dictionary. 
Get operation: Here I am checking if the element exists in the dictionary, if yes, then I am removing the node from the doubly linked list, adding it to the front of the list and returning the node value.
Time Complexity: O(1)
Since I am using a doubly linked list and a dictionary to store and retrieve the items, searching and retrieving takes O(1) time
Space Complexity: O(n)
LRU Cache stores the nodes in the order of most recently used to least recently used and since I am using a doubly linked list of length n and a dictionary of length n which makes the total space used for each node O(n) where n is the total number of nodes in the list.


Problem 2: Finding Files
For this problem recursion is used which checked each entry for the encountered folder and it also checks if the path is a file or a directory.
Time Complexity: O(n*m)
Where n is the total number of files in each folder that need to be traversed and m which is the total number of folders that need to be traversed before finding the file.
Space Complexity:
N = Total space required by the input list
S = Total space required by the returned file’s list
D = Total number of directories traversed which affects the number of calls in the recursive stack which is the worst case. In the case where only 1 directory is present(best case) there will be no call stack.


O(N + S + D) is the over space complexity


Problem 3: Huffman Coding
The steps I used here are creating and sorting a dictionary, building the tree and then trimming it such that only the characters are shown and the totals are removed and then encoding the tree with 0’s and 1’s.


Time Complexity:
Here since multiple steps are involved I have shown all the steps and time complexities below,
Creating a dictionary: O(n)
Since I navigated through the entire data once and added them into the dictionary. Here n is the length of the input data
Making a list of tuples using the dictionary: O(n) 
Since I am navigating through the dictionary once and creating the list. Here n is the number of keys in the dictionary
Building the tree and trimming the tree: O(n^2 logn)
This is because <list>/sort() is being done n times, where n is the number of unique characters. 
Encoding: O(n^2)
This is recursive call for both left and right subtree and this is the most time consuming process in this algorithm. Here I am constructing a huffman tree with the trimmed tree. Here n is the total height of the tree. 
Decoding: O(n)
Decoding takes O(n) time this is just navigating through the encoded string while checking if the dictionary of encoded values have that particular string of encoded characters or not. Here n is the total length of the encoded value


Space Complexity: 
Total Space complexity is shown below,


O(
length of dictionary which stored the number of occurrences of a character + 
length of the dictionary that stores the key and its encoded value + 
space for storing the tree which is O(n) where n is the height + 
Length of the recursive stack that is used during encoding +
length of the list of tuples
) 
along with few pointers and strings which store the encoded and decoded value.
The length of the decoded value will depend on the length of the encoded data input. 


Problem 4: Active Directory
Here I am navigating checking the entire structure worst case to find the user.
Time Complexity: O(n*m)
Where n is the total number of uses in each group that need to be traversed and m which is the total number of subgroups within a group that need to be traversed before finding the file.


Space complexity:


N  = Here n is the recursive stack length.
A = Length of the Auxiliary lists that occupy space
D = Depth of the recursive call stack worst case if the groups are nested. Best case this value will be 0 because there will only be one group


So the total space complexity is O(N + A + D)
Problem 5: BlockChain:
Here block chain is implemented as a linked list where each block has a previous hash value which is the  reference of the previous block. 
Time Complexity: 
Append: Append takes O(1) time complexity since adding a node to a linked list is constant time
Space Complexity: 
Here space complexity considers 3 factors, Space required by the block which affects the space required by the linked list and the list that is used to store the blockchain.
NL = Total number of nodes in the linked list.
B = Length of the blockchain linked list. 
Total Space complexity  = O(NL + B)


Problem 6: Union and intersection
Time Complexity of Union:
O(n ^ 2) - Copying the list takes O(n) time and append the list takes another O(n) time. 


Time Complexity for Intersection: 
O(m * n) - where m is the length of first input and n is the length of the second input. Since set is used the lookup is faster which is O(1)


Space complexity: 
O(length of first linked list + length of 2nd linked list + length of temporary linked list)